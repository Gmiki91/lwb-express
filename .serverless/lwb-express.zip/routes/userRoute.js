const Router = require('express');
const router = Router();
const userController = require('../controllers/userController');

router.route('/signup').post(userController.signup)
router.route('/login').post(userController.login)
  
module.exports = router;